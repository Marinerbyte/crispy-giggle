import WebSocket from "ws";
import { getToken } from "./howdies";

interface BotContext {
  currentRoom: string;
  translateUsers: Record<string, boolean>;
  getGeminiResponse: (prompt: string, context?: string) => Promise<string>;
  translateToHinglish: (message: string) => Promise<string>;
  getHfImage: (prompt: string) => Promise<{ filename: string | null; error: string | null }>;
  uploadFile: (filename: string, token: string, isImage?: boolean) => Promise<string | null>;
  sendMessage: (text: string) => Promise<boolean>;
  emitMessage: (sender: string, text: string, type: string, imageUrl?: string) => void;
  emitLog: (text: string, level?: string) => void;
  emitError: (text: string) => void;
  getToken?: () => Promise<string | null>;
}

export async function handleMessage(
  ws: WebSocket,
  data: any,
  context: BotContext
) {
  const { sender, text, roomid } = data;
  const {
    currentRoom,
    translateUsers,
    getGeminiResponse,
    translateToHinglish,
    getHfImage,
    uploadFile,
    emitLog,
    emitMessage,
    emitError
  } = context;

  // Skip processing messages from the bot itself
  if (sender === "kamina") {
    return;
  }

  // Check if translation is enabled for this user
  if (translateUsers[sender]) {
    try {
      const translatedText = await translateToHinglish(text);
      emitLog(`Translated message from ${sender}: "${text}" -> "${translatedText}"`, "info");
      
      // Send translated message to all users
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: `[Translated] ${sender}: ${translatedText}`
      };
      ws.send(JSON.stringify(payload));
    } catch (error) {
      emitError(`Translation error: ${error}`);
    }
  }

  // Handle commands
  if (text.startsWith("/join ") && sender.toLowerCase() === "yasin") {
    try {
      const roomName = text.substring(6).trim();
      if (!roomName) {
        throw new Error("Room name cannot be empty!");
      }
      
      const payload = {
        handler: "joinchatroom",
        name: roomName,
        roomPassword: ""
      };
      ws.send(JSON.stringify(payload));
      
      emitLog(`Joining room: ${roomName} (requested by ${sender})`, "info");
    } catch (error) {
      const errorMessage = `Error joining room: ${error}`;
      emitError(errorMessage);
      
      // Reply to user with error
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: `Error: ${error} Use /join <room name>`
      };
      ws.send(JSON.stringify(payload));
    }
    return;
  }

  if (text.startsWith("/translate ")) {
    try {
      const targetUser = text.split(" ")[1].trim();
      if (targetUser === "kamina") {
        const payload = {
          handler: "chatroommessage",
          type: "text",
          roomid: currentRoom,
          text: "Bot ke messages translate nahi kar sakta!"
        };
        ws.send(JSON.stringify(payload));
        return;
      }
      
      translateUsers[targetUser] = true;
      emitLog(`Translation enabled for user: ${targetUser} (requested by ${sender})`, "success");
      
      // Send confirmation
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: `Translating ${targetUser}'s messages to Hinglish!`
      };
      ws.send(JSON.stringify(payload));
    } catch (error) {
      emitError(`Translation error: ${error}`);
      
      // Send error message
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: "Invalid command! Use /translate <username>"
      };
      ws.send(JSON.stringify(payload));
    }
    return;
  }

  if (text.startsWith("/offtranslate ")) {
    try {
      const targetUser = text.split(" ")[1].trim();
      if (translateUsers[targetUser]) {
        translateUsers[targetUser] = false;
        emitLog(`Translation disabled for user: ${targetUser} (requested by ${sender})`, "info");
        
        // Send confirmation
        const payload = {
          handler: "chatroommessage",
          type: "text",
          roomid: currentRoom,
          text: `Stopped translating ${targetUser}'s messages.`
        };
        ws.send(JSON.stringify(payload));
      } else {
        // Send error message
        const payload = {
          handler: "chatroommessage",
          type: "text",
          roomid: currentRoom,
          text: `${targetUser} ke liye translation on nahi tha!`
        };
        ws.send(JSON.stringify(payload));
      }
    } catch (error) {
      emitError(`Translation error: ${error}`);
      
      // Send error message
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: "Invalid command! Use /offtranslate <username>"
      };
      ws.send(JSON.stringify(payload));
    }
    return;
  }

  // Handle "kamina" keyword - respond with Gemini API
  if (text.toLowerCase().includes("kamina")) {
    try {
      emitLog(`Processing "kamina" request from ${sender}: "${text}"`, "info");
      
      // If it's just the word "kamina", send a roast
      if (text.toLowerCase().trim() === "kamina") {
        const roast = await getGeminiResponse("Generate a short funny roast in Hinglish", 
                                              `Target user: ${sender}. Make it funny and not offensive.`);
        
        const payload = {
          handler: "chatroommessage",
          type: "text",
          roomid: currentRoom,
          text: roast
        };
        ws.send(JSON.stringify(payload));
        
        emitMessage("Kamina Bot", roast, "text");
        return;
      }
      
      // Otherwise treat as a question or command
      const question = text.replace(/kamina/i, "").trim();
      const answer = await getGeminiResponse(question);
      
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: answer
      };
      ws.send(JSON.stringify(payload));
      
      emitMessage("Kamina Bot", answer, "text");
    } catch (error) {
      emitError(`Error processing "kamina" request: ${error}`);
      
      // Send error message
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: "Error processing your request. Please try again."
      };
      ws.send(JSON.stringify(payload));
    }
    return;
  }

  // Handle image generation requests
  if (text.toLowerCase().includes("generate an image of")) {
    try {
      emitLog(`Processing image generation request from ${sender}: "${text}"`, "info");
      
      const prompt = text.replace(/generate an image of/i, "").trim();
      
      // Send acknowledgement
      const ackPayload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: `Generating image for prompt: "${prompt}"... Please wait.`
      };
      ws.send(JSON.stringify(ackPayload));
      
      // Generate the image
      const { filename, error } = await getHfImage(prompt);
      
      if (filename && !error) {
        // Get authentication token
        const authToken = process.env.HOWDIES_TOKEN || await getToken();
        
        if (!authToken) {
          throw new Error("Failed to get authentication token for file upload");
        }
        
        // Upload the image
        const fileId = await uploadFile(filename, authToken, true);
        
        if (fileId) {
          // Send the image
          const imagePayload = {
            handler: "chatroommessage",
            type: "image",
            roomid: currentRoom,
            fileid: fileId,
            text: `Generated image for: "${prompt}"`
          };
          ws.send(JSON.stringify(imagePayload));
          
          emitMessage("Kamina Bot", `Generated image for: "${prompt}"`, "image", fileId);
        } else {
          throw new Error("Failed to upload image");
        }
      } else {
        throw new Error(error || "Unknown error generating image");
      }
    } catch (error) {
      emitError(`Error generating image: ${error}`);
      
      // Send error message
      const payload = {
        handler: "chatroommessage",
        type: "text",
        roomid: currentRoom,
        text: `Failed to generate image: ${error}`
      };
      ws.send(JSON.stringify(payload));
    }
    return;
  }
}
