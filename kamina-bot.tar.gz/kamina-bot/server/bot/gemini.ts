import axios from "axios";
import fs from "fs";
import path from "path";
import { randomUUID } from "crypto";

// API keys from environment variables
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || "";
const HUGGINGFACE_API_KEY = process.env.HUGGINGFACE_API_KEY || "";

// API URLs
const GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent";
const HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2-1";

// Get text response from Gemini API
export async function getGeminiResponse(prompt: string, context: string = ""): Promise<string> {
  try {
    if (!GEMINI_API_KEY) {
      return "GEMINI_API_KEY not set in environment variables!";
    }

    const headers = { "Content-Type": "application/json" };
    const payload = {
      contents: [{ parts: [{ text: `${context}\n${prompt}` }] }]
    };

    const response = await axios.post(
      `${GEMINI_API_URL}?key=${GEMINI_API_KEY}`,
      payload,
      { headers }
    );

    if (response.status === 200 && response.data.candidates && response.data.candidates.length > 0) {
      return response.data.candidates[0].content.parts[0].text;
    }
    return "API se response nahi aaya!";
  } catch (error) {
    console.error("Gemini API error:", error);
    return "AI down hai, baad mein try kar!";
  }
}

// Translate message to Hinglish using Gemini
export async function translateToHinglish(message: string): Promise<string> {
  try {
    const context = `Translate this message to Hinglish (Hindi-English mix, casual tone): ${message}`;
    const translated = await getGeminiResponse("Translate to Hinglish", context);
    return translated;
  } catch (error) {
    console.error("Translation error:", error);
    return "Translation failed!";
  }
}

// Generate image using Hugging Face Stable Diffusion
export async function getHfImage(prompt: string): Promise<{ filename: string | null; error: string | null }> {
  try {
    if (!HUGGINGFACE_API_KEY) {
      return { filename: null, error: "Hugging Face API key not set!" };
    }

    const headers = { 
      "Authorization": `Bearer ${HUGGINGFACE_API_KEY}`,
      "Content-Type": "application/json"
    };
    const payload = { "inputs": prompt };

    const response = await axios.post(HF_API_URL, payload, { 
      headers,
      responseType: 'arraybuffer'
    });

    if (response.status === 200) {
      const filename = `image_${randomUUID()}.png`;
      const filePath = path.join(process.cwd(), filename);
      
      fs.writeFileSync(filePath, response.data);
      return { filename, error: null };
    }
    
    return { filename: null, error: "Image generation failed!" };
  } catch (error) {
    console.error("Hugging Face API error:", error);
    return { filename: null, error: "Image generation error!" };
  }
}
