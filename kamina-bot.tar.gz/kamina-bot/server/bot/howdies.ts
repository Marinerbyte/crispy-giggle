import axios from "axios";
import fs from "fs";
import WebSocket from "ws";

// Howdies API endpoints
const LOGIN_URL = "https://api.howdies.app/api/login";
const UPLOAD_URL = "https://api.howdies.app/api/upload";

// Get Howdies auth token
export async function getToken(captchaToken: string | null = null): Promise<string | null> {
  try {
    const payload: any = {
      username: "kamina",
      password: "p99665"
    };
    
    if (captchaToken) {
      payload.captcha_token = captchaToken;
    }
    
    const response = await axios.post(LOGIN_URL, payload);
    
    if (response.status === 200 && response.data.token) {
      return response.data.token;
    }
    
    if (response.status === 429) {
      console.log("Rate limit hit on login API!");
      return null;
    }
    
    if (response.data.captcha_url) {
      console.log("Captcha required:", response.data.captcha_url);
      return null;
    }
    
    return null;
  } catch (error) {
    console.error("Login error:", error);
    return null;
  }
}

// Login to WebSocket
export function login(ws: WebSocket, username: string, password: string): void {
  try {
    const payload = {
      handler: "login",
      username,
      password
    };
    
    ws.send(JSON.stringify(payload));
  } catch (error) {
    console.error("WebSocket login error:", error);
  }
}

// Upload file to Howdies
export async function uploadFile(filename: string, token: string, isImage: boolean = false): Promise<string | null> {
  try {
    if (!fs.existsSync(filename)) {
      console.error(`File not found: ${filename}`);
      return null;
    }
    
    // Use FormData from form-data package for Node.js
    const FormData = require('form-data');
    const formData = new FormData();
    const fileBuffer = fs.readFileSync(filename);
    
    formData.append('file', fileBuffer, {
      filename: filename,
      contentType: isImage ? 'image/png' : 'audio/mpeg'
    });
    
    const headers = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'multipart/form-data'
    };
    
    const response = await axios.post(UPLOAD_URL, formData, { headers });
    
    if (response.status === 200) {
      const data = response.data;
      const fileId = data.file_id || data.id || data.file;
      
      if (fileId) {
        console.log(`Uploaded successfully. File ID: ${fileId}`);
        return fileId;
      }
    }
    
    return null;
  } catch (error) {
    console.error("Upload error:", error);
    return null;
  }
}
