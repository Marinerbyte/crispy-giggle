import { WebSocket } from "ws";
import axios from "axios";
import EventEmitter from "events";
import { v4 as uuidv4 } from "uuid";
import { getGeminiResponse, translateToHinglish, getHfImage } from "./gemini";
import { getToken, login, uploadFile } from "./howdies";
import { handleMessage } from "./handlers";

// Bot configuration
const BOT_USERNAME = "kamina";
const BOT_PASSWORD = "p99665";
const MASTER_USER = "yasin";
const DEFAULT_ROOM = "🏏Atlanta🏏";
const RECONNECT_DELAY = 15; // seconds
const MAX_RECONNECT_ATTEMPTS = 3;
const CAPTCHA_TIMEOUT = 45; // seconds
const DM_COOLDOWN = 30; // seconds
const WS_URL = "wss://app.howdies.app/";

// Import storage for database interactions
import { storage } from "../storage";

// Bot state
let wsInstance: WebSocket | null = null;
let token: string | null = null;
let currentRoom = DEFAULT_ROOM;
let isConnecting = false;
let reconnectAttempts = 0;
let lastDmTime = 0;
let usersInRoom: string[] = [];
let translateUsers: Record<string, boolean> = {};

// Bot message history
let messageHistory: any[] = [];

// Load the translation settings from database on startup
async function loadTranslationSettings() {
  try {
    const translatedUsers = await storage.getTranslatedUsers();
    translatedUsers.forEach(user => {
      translateUsers[user.username] = true;
    });
    console.log(`Loaded ${translatedUsers.length} translated users from database`);
  } catch (error) {
    console.error("Failed to load translation settings:", error);
  }
}

// Helper functions to emit events to the main server
function emitMessage(sender: string, text: string, type: string = "text", imageUrl?: string) {
  // Using emit as any to bypass TypeScript restrictions
  (process as any).emit('botMessage', { sender, text, type, imageUrl });
}

function emitStatus(connected: boolean, room: string) {
  (process as any).emit('botStatus', { connected, room });
}

function emitLog(text: string, level: string = "info") {
  (process as any).emit('botLog', { text, level });
  
  // Store log in database
  try {
    storage.createLog({ text, level }).catch(e => 
      console.error("Failed to store log in database:", e)
    );
  } catch (error) {
    console.error("Error storing log in database:", error);
  }
}

function emitError(text: string) {
  (process as any).emit('botError', { text });
  emitLog(text, "error");
}

function emitUsers(users: string[]) {
  (process as any).emit('botUsers', { users: users.map(username => ({ username })) });
}

function emitTranslate(username: string) {
  (process as any).emit('botTranslate', { username });
}

function emitOffTranslate(username: string) {
  (process as any).emit('botOffTranslate', { username });
}

// Initialize the bot
export async function startBot() {
  if (wsInstance && wsInstance.readyState === WebSocket.OPEN) {
    emitLog("Bot is already running", "warning");
    return;
  }
  
  try {
    emitLog("Starting bot...", "info");
    
    // Load translation settings from database
    await loadTranslationSettings();
    
    // Get auth token
    const authToken = await getToken();
    
    if (!authToken) {
      emitError("Failed to get authentication token");
      return;
    }
    
    token = authToken;
    connectWebSocket();
    
    // Store bot startup in logs
    await storage.createLog({
      text: "Bot started successfully",
      level: "success"
    });
    
    emitStatus(true, currentRoom);
    emitLog("Bot started successfully", "success");
    
    return true;
  } catch (error) {
    emitError(`Failed to start bot: ${error}`);
    
    // Store error in logs
    try {
      await storage.createLog({
        text: `Failed to start bot: ${error}`,
        level: "error"
      });
    } catch (logError) {
      console.error("Failed to log error to database:", logError);
    }
    
    return false;
  }
}

// Stop the bot
export async function stopBot() {
  if (wsInstance) {
    wsInstance.close();
    wsInstance = null;
  }
  
  emitStatus(false, currentRoom);
  emitLog("Bot stopped", "info");
  
  return true;
}

// Check if the bot is connected
export function isConnected() {
  return wsInstance !== null && wsInstance.readyState === WebSocket.OPEN;
}

// Get the current room
export function getCurrentRoom() {
  return currentRoom;
}

// Send a message to the current room
export async function sendMessage(text: string) {
  if (!isConnected()) {
    emitError("Bot is not connected");
    return false;
  }
  
  try {
    const payload = {
      handler: "chatroommessage",
      type: "text",
      roomid: currentRoom,
      text
    };
    
    if (wsInstance) {
      wsInstance.send(JSON.stringify(payload));
      emitLog(`Message sent to ${currentRoom}: ${text.substring(0, 30)}${text.length > 30 ? '...' : ''}`, "info");
      return true;
    } else {
      emitError("WebSocket instance is null");
      return false;
    }
  } catch (error) {
    emitError(`Failed to send message: ${error}`);
    return false;
  }
}

// Join a room
export async function joinRoom(roomName: string) {
  if (!isConnected()) {
    emitError("Bot is not connected");
    return false;
  }
  
  try {
    const payload = {
      handler: "joinchatroom",
      name: roomName,
      roomPassword: ""
    };
    
    if (wsInstance) {
      wsInstance.send(JSON.stringify(payload));
      emitLog(`Joining room: ${roomName}`, "info");
      
      // Update current room optimistically (will be corrected if join fails)
      currentRoom = roomName;
      emitStatus(true, currentRoom);
      
      return true;
    } else {
      emitError("WebSocket instance is null");
      return false;
    }
  } catch (error) {
    emitError(`Failed to join room: ${error}`);
    return false;
  }
}

// Enable translation for a user
export async function translateUser(username: string) {
  try {
    // Update in-memory state
    translateUsers[username] = true;
    
    // Save to database
    await storage.enableTranslation(username);
    
    // Log and notify
    emitLog(`Translation enabled for user: ${username}`, "success");
    emitTranslate(username);
    
    // Store log in database
    await storage.createLog({
      text: `Translation enabled for user: ${username}`,
      level: "success"
    });
    
    return true;
  } catch (error) {
    emitError(`Failed to enable translation for ${username}: ${error}`);
    return false;
  }
}

// Disable translation for a user
export async function offTranslateUser(username: string) {
  try {
    // Update in-memory state
    translateUsers[username] = false;
    
    // Save to database
    await storage.disableTranslation(username);
    
    // Log and notify
    emitLog(`Translation disabled for user: ${username}`, "info");
    emitOffTranslate(username);
    
    // Store log in database
    await storage.createLog({
      text: `Translation disabled for user: ${username}`,
      level: "info"
    });
    
    return true;
  } catch (error) {
    emitError(`Failed to disable translation for ${username}: ${error}`);
    return false;
  }
}

// Get current bot state
export function getBotState() {
  return {
    connected: isConnected(),
    room: currentRoom,
    messages: messageHistory,
    users: usersInRoom.map(username => ({ username })),
    translatedUsers: Object.keys(translateUsers).filter(username => translateUsers[username])
  };
}

// Connect to WebSocket
function connectWebSocket() {
  if (isConnecting || (wsInstance && wsInstance.readyState === WebSocket.CONNECTING)) {
    return;
  }
  
  isConnecting = true;
  
  const wsUrl = token ? `${WS_URL}?token=${token}` : WS_URL;
  wsInstance = new WebSocket(wsUrl);
  
  if (wsInstance) {
    wsInstance.onopen = () => {
      isConnecting = false;
      reconnectAttempts = 0;
      emitLog("Connected to Howdies WebSocket", "success");
      
      // Login after connection
      if (wsInstance) {
        login(wsInstance, BOT_USERNAME, BOT_PASSWORD);
        
        // Join default room
        setTimeout(() => {
          joinRoom(DEFAULT_ROOM);
        }, 1000);
      }
    };
    
    wsInstance.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data.toString());
        
        // Handle different message types
        if (data.handler === "chatroommessage") {
          const { sender, text } = data;
          
          // Add message to history
          const messageId = uuidv4();
          const message = {
            id: messageId,
            sender,
            text,
            type: "text",
            timestamp: new Date().toISOString()
          };
          
          messageHistory.push(message);
          if (messageHistory.length > 100) {
            messageHistory.shift(); // Keep only the last 100 messages
          }
          
          // Emit to frontend
          emitMessage(sender, text, "text");
          
          // Handle bot commands and responses
          if (wsInstance) {
            handleMessage(wsInstance, data, {
              currentRoom,
              translateUsers,
              getGeminiResponse,
              translateToHinglish,
              getHfImage,
              uploadFile,
              sendMessage,
              emitMessage,
              emitLog,
              emitError,
              getToken
            });
          }
        }
        else if (data.handler === "users") {
          usersInRoom = data.users || [];
          emitUsers(usersInRoom);
          emitLog(`User list updated: ${usersInRoom.length} users`, "info");
        }
        else if (data.handler === "joined") {
          currentRoom = data.room || currentRoom;
          emitStatus(true, currentRoom);
          emitMessage("SYSTEM", `Bot has joined the room: ${currentRoom}`, "system");
          emitLog(`Successfully joined room: ${currentRoom}`, "success");
        }
      } catch (error) {
        emitError(`Error processing WebSocket message: ${error}`);
      }
    };
    
    wsInstance.onclose = () => {
      isConnecting = false;
      emitStatus(false, currentRoom);
      emitLog("Disconnected from WebSocket", "error");
      
      // Attempt to reconnect
      if (reconnectAttempts < MAX_RECONNECT_ATTEMPTS) {
        reconnectAttempts++;
        emitLog(`Reconnecting... Attempt ${reconnectAttempts}/${MAX_RECONNECT_ATTEMPTS}`, "warning");
        
        setTimeout(() => {
          connectWebSocket();
        }, RECONNECT_DELAY * 1000);
      } else {
        emitError("Max reconnect attempts reached. Please restart the bot manually.");
      }
    };
    
    wsInstance.onerror = (error) => {
      isConnecting = false;
      emitError(`WebSocket error: ${error.message || "Unknown error"}`);
    };
  }
}

// Export functions and events
export {
  emitMessage,
  emitLog,
  emitError,
  emitStatus
};
