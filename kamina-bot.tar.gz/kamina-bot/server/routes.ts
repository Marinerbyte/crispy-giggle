import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { startBot, stopBot, isConnected, getCurrentRoom, sendMessage, joinRoom, translateUser, offTranslateUser, getBotState } from "./bot/index";

// A map to keep track of connected websocket clients
const clients = new Map<WebSocket, { id: string }>();

export async function registerRoutes(app: Express): Promise<Server> {
  const httpServer = createServer(app);
  
  // Initialize the WebSocket server on a different path than Vite's HMR
  const wss = new WebSocketServer({ server: httpServer, path: '/api/ws' });
  
  // Start the bot on server initialization
  try {
    await startBot();
    console.log('Bot started successfully');
  } catch (error) {
    console.error('Failed to start bot:', error);
  }
  
  // REST API endpoints
  
  // Bot status endpoint
  app.get('/api/bot/status', async (req, res) => {
    try {
      const status = {
        connected: isConnected(),
        room: getCurrentRoom()
      };
      res.json(status);
    } catch (error) {
      res.status(500).json({ error: 'Failed to get bot status' });
    }
  });
  
  // Start bot endpoint
  app.post('/api/bot/start', async (req, res) => {
    try {
      await startBot();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to start bot' });
    }
  });
  
  // Stop bot endpoint
  app.post('/api/bot/stop', async (req, res) => {
    try {
      await stopBot();
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to stop bot' });
    }
  });
  
  // Send message endpoint
  app.post('/api/bot/message', async (req, res) => {
    try {
      const { text } = req.body;
      if (!text) {
        return res.status(400).json({ error: 'Message text is required' });
      }
      
      await sendMessage(text);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to send message' });
    }
  });
  
  // Join room endpoint
  app.post('/api/bot/join', async (req, res) => {
    try {
      const { roomName } = req.body;
      if (!roomName) {
        return res.status(400).json({ error: 'Room name is required' });
      }
      
      await joinRoom(roomName);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to join room' });
    }
  });
  
  // Translate user endpoint
  app.post('/api/bot/translate', async (req, res) => {
    try {
      const { username } = req.body;
      if (!username) {
        return res.status(400).json({ error: 'Username is required' });
      }
      
      await translateUser(username);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to enable translation' });
    }
  });
  
  // Offtranslate user endpoint
  app.post('/api/bot/offtranslate', async (req, res) => {
    try {
      const { username } = req.body;
      if (!username) {
        return res.status(400).json({ error: 'Username is required' });
      }
      
      await offTranslateUser(username);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: 'Failed to disable translation' });
    }
  });
  
  // WebSocket connection handling
  wss.on('connection', (ws) => {
    const clientId = Math.random().toString(36).substring(2, 15);
    clients.set(ws, { id: clientId });
    console.log(`Client connected: ${clientId}`);
    
    // Function to safely send messages over WebSocket
    const safeSend = (data: any) => {
      try {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify(data));
        }
      } catch (error) {
        console.error(`Error sending message to client ${clientId}:`, error);
      }
    };
    
    // Send the current state to the new client
    const botState = getBotState();
    safeSend({
      type: 'status',
      connected: botState.connected,
      room: botState.room
    });
    
    // Send the last 50 messages if available
    if (botState.messages && botState.messages.length > 0) {
      const lastMessages = botState.messages.slice(-50);
      lastMessages.forEach(msg => {
        safeSend({
          type: 'message',
          sender: msg.sender,
          text: msg.text,
          messageType: msg.type,
          imageUrl: msg.imageUrl
        });
      });
    }
    
    // Send the user list
    if (botState.users && botState.users.length > 0) {
      safeSend({
        type: 'users',
        users: botState.users
      });
    }
    
    // Handle messages from clients
    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'message') {
          await sendMessage(message.text);
        } 
        else if (message.type === 'join') {
          await joinRoom(message.room);
        }
        else if (message.type === 'translate') {
          await translateUser(message.username);
        }
        else if (message.type === 'offtranslate') {
          await offTranslateUser(message.username);
        }
      } catch (error) {
        console.error('Error handling WebSocket message:', error);
        ws.send(JSON.stringify({
          type: 'error',
          text: 'Failed to process your request'
        }));
      }
    });
    
    // Handle client disconnection
    ws.on('close', () => {
      const client = clients.get(ws);
      if (client) {
        console.log(`Client disconnected: ${client.id}`);
        clients.delete(ws);
      }
    });
  });
  
  // Setup event handlers to broadcast bot events to all WebSocket clients
  const broadcastToAll = (data: any) => {
    const message = JSON.stringify(data);
    clients.forEach((client, ws) => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.send(message);
      }
    });
  };
  
  // Listen for bot events and broadcast them to all clients
  // These events will be emitted by the bot implementation
  process.on('botMessage', (data) => {
    broadcastToAll({
      type: 'message',
      sender: data.sender,
      text: data.text,
      messageType: data.type,
      imageUrl: data.imageUrl
    });
  });
  
  process.on('botStatus', (data) => {
    broadcastToAll({
      type: 'status',
      connected: data.connected,
      room: data.room
    });
  });
  
  process.on('botLog', (data) => {
    broadcastToAll({
      type: 'log',
      text: data.text,
      level: data.level
    });
  });
  
  process.on('botError', (data) => {
    broadcastToAll({
      type: 'error',
      text: data.text
    });
  });
  
  process.on('botUsers', (data) => {
    broadcastToAll({
      type: 'users',
      users: data.users
    });
  });
  
  process.on('botTranslate', (data) => {
    broadcastToAll({
      type: 'translate',
      username: data.username
    });
  });
  
  process.on('botOffTranslate', (data) => {
    broadcastToAll({
      type: 'offtranslate',
      username: data.username
    });
  });

  // Handle process termination to clean up resources
  process.on('SIGINT', async () => {
    try {
      await stopBot();
      console.log('Bot stopped gracefully');
      process.exit(0);
    } catch (error) {
      console.error('Error stopping bot:', error);
      process.exit(1);
    }
  });

  return httpServer;
}
