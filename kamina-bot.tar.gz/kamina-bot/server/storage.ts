import { 
  users, translatedUsers, messages, logs, botConfig,
  type User, type InsertUser, type Message, type InsertMessage,
  type TranslatedUser, type InsertTranslatedUser, type Log, type InsertLog,
  type BotConfig, type InsertBotConfig
} from "@shared/schema";
import { db } from "./db";
import { eq, desc, sql } from "drizzle-orm";

// Storage interface for CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Message operations
  getMessages(roomId: string, limit?: number): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  
  // Translated user operations
  getTranslatedUsers(): Promise<TranslatedUser[]>;
  getTranslatedUser(username: string): Promise<TranslatedUser | undefined>;
  enableTranslation(username: string): Promise<TranslatedUser>;
  disableTranslation(username: string): Promise<void>;
  
  // Log operations
  getLogs(limit?: number): Promise<Log[]>;
  createLog(log: InsertLog): Promise<Log>;
  clearLogs(): Promise<void>;
  
  // Bot config operations
  getConfig(key: string): Promise<string | undefined>;
  setConfig(key: string, value: string): Promise<void>;
}

// Database storage implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }
  
  // Message operations
  async getMessages(roomId: string, limit: number = 100): Promise<Message[]> {
    return await db
      .select()
      .from(messages)
      .where(eq(messages.roomId, roomId))
      .orderBy(desc(messages.timestamp))
      .limit(limit);
  }
  
  async createMessage(message: InsertMessage): Promise<Message> {
    const [newMessage] = await db.insert(messages).values(message).returning();
    return newMessage;
  }
  
  // Translated user operations
  async getTranslatedUsers(): Promise<TranslatedUser[]> {
    return await db
      .select()
      .from(translatedUsers)
      .where(eq(translatedUsers.enabled, true));
  }
  
  async getTranslatedUser(username: string): Promise<TranslatedUser | undefined> {
    const [user] = await db
      .select()
      .from(translatedUsers)
      .where(eq(translatedUsers.username, username));
    return user;
  }
  
  async enableTranslation(username: string): Promise<TranslatedUser> {
    // Check if user exists first
    const existingUser = await this.getTranslatedUser(username);
    
    if (existingUser) {
      // Update existing record
      const [updated] = await db
        .update(translatedUsers)
        .set({ enabled: true })
        .where(eq(translatedUsers.username, username))
        .returning();
      return updated;
    } else {
      // Create new record
      const [newUser] = await db
        .insert(translatedUsers)
        .values({ username, enabled: true })
        .returning();
      return newUser;
    }
  }
  
  async disableTranslation(username: string): Promise<void> {
    await db
      .update(translatedUsers)
      .set({ enabled: false })
      .where(eq(translatedUsers.username, username));
  }
  
  // Log operations
  async getLogs(limit: number = 100): Promise<Log[]> {
    return await db
      .select()
      .from(logs)
      .orderBy(desc(logs.timestamp))
      .limit(limit);
  }
  
  async createLog(log: InsertLog): Promise<Log> {
    const [newLog] = await db.insert(logs).values(log).returning();
    return newLog;
  }
  
  async clearLogs(): Promise<void> {
    await db.delete(logs);
  }
  
  // Bot config operations
  async getConfig(key: string): Promise<string | undefined> {
    const [config] = await db
      .select()
      .from(botConfig)
      .where(eq(botConfig.key, key));
    return config?.value;
  }
  
  async setConfig(key: string, value: string): Promise<void> {
    const [existingConfig] = await db
      .select()
      .from(botConfig)
      .where(eq(botConfig.key, key));
    
    if (existingConfig) {
      await db
        .update(botConfig)
        .set({ value, updatedAt: sql`CURRENT_TIMESTAMP` })
        .where(eq(botConfig.key, key));
    } else {
      await db
        .insert(botConfig)
        .values({ key, value });
    }
  }
}

// Export instance of database storage
export const storage = new DatabaseStorage();
