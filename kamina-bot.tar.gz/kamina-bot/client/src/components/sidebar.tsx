import { BotState, BotActions } from "@/types";
import { StatusCard } from "./status-card";
import { UserInfoPanel } from "./user-info-panel";
import { RoomStats } from "./room-stats";
import { CommandHelp } from "./command-help";
import { useState } from "react";

interface SidebarProps {
  botState: BotState;
  botActions: BotActions;
}

export function Sidebar({ botState, botActions }: SidebarProps) {
  const [activeTab, setActiveTab] = useState<'status' | 'config'>('status');
  
  return (
    <div className="w-full md:w-64 bg-darker border-r border-gray-700 flex flex-col">
      <StatusCard 
        connected={botState.connected}
        room={botState.room}
      />
      
      <div className="flex bg-darker border-b border-gray-700">
        <button 
          className={`flex-1 py-2 text-sm font-medium ${activeTab === 'status' ? 'text-white bg-gray-800' : 'text-gray-400 hover:text-white'} border-r border-gray-700`}
          onClick={() => setActiveTab('status')}
        >
          Status
        </button>
        <button 
          className={`flex-1 py-2 text-sm font-medium ${activeTab === 'config' ? 'text-white bg-gray-800' : 'text-gray-400 hover:text-white'}`}
          onClick={() => setActiveTab('config')}
        >
          Config
        </button>
      </div>
      
      {activeTab === 'status' && (
        <>
          <UserInfoPanel 
            lookupUser={botActions.lookupUser} 
            translateUser={botActions.translateUser}
            stopTranslatingUser={botActions.stopTranslatingUser}
            translatedUsers={botState.translatedUsers}
          />
          
          <RoomStats 
            userCount={botState.users.length} 
            messageCount={botState.messages.filter(m => m.type !== 'system').length}
            activeUsers={Math.max(5, Math.floor(botState.users.length / 2))} // Simulate active users
          />
          
          <CommandHelp />
        </>
      )}
      
      {activeTab === 'config' && (
        <div className="p-4 flex-1 overflow-y-auto">
          <h3 className="text-sm font-semibold text-gray-300 mb-2">Bot Configuration</h3>
          <div className="space-y-3 text-xs">
            <div className="bg-gray-800 rounded p-3 space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-400">Bot Username:</span>
                <span className="text-white">kamina</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Default Room:</span>
                <span className="text-white">🏏Atlanta🏏</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Master User:</span>
                <span className="text-white">yasin</span>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded p-3">
              <h4 className="text-sm font-medium text-white mb-2">API Status</h4>
              <div className="space-y-1">
                <div className="flex justify-between">
                  <span className="text-gray-400">Howdies API:</span>
                  <span className="text-green-400">Connected</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Gemini API:</span>
                  <span className="text-green-400">Active</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-400">Hugging Face:</span>
                  <span className="text-gray-400">Available</span>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded p-3">
              <h4 className="text-sm font-medium text-white mb-2">Translation</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-gray-400">Active Translations:</span>
                  <span className="text-white">{botState.translatedUsers.length}</span>
                </div>
                {botState.translatedUsers.length > 0 ? (
                  <div className="text-xs bg-gray-900 p-2 rounded">
                    {botState.translatedUsers.map((user, idx) => (
                      <div key={idx} className="flex justify-between items-center mb-1 last:mb-0">
                        <span className="text-white">{user}</span>
                        <button 
                          className="text-red-400 hover:text-red-300 text-xs"
                          onClick={() => botActions.stopTranslatingUser(user)}
                        >
                          Disable
                        </button>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-xs bg-gray-900 p-2 rounded text-gray-400">
                    No active translations
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
