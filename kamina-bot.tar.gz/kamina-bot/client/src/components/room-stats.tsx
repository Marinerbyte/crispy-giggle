interface RoomStatsProps {
  userCount: number;
  messageCount: number;
  activeUsers: number;
}

export function RoomStats({ userCount, messageCount, activeUsers }: RoomStatsProps) {
  return (
    <div className="p-4 border-b border-gray-700">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-sm font-semibold text-gray-300">Room Stats</h3>
        <span className="text-xs bg-gray-700 px-2 py-0.5 rounded text-gray-300">Live</span>
      </div>
      <div className="bg-gray-800 rounded-lg p-3 text-sm">
        <div className="flex justify-between mb-1">
          <span className="text-gray-400">Users:</span>
          <span className="text-white">{userCount}</span>
        </div>
        <div className="flex justify-between mb-1">
          <span className="text-gray-400">Messages:</span>
          <span className="text-white">{messageCount}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-gray-400">Active:</span>
          <span className="text-white">{activeUsers}</span>
        </div>
      </div>
    </div>
  );
}
