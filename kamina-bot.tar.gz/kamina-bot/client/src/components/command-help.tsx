export function CommandHelp() {
  return (
    <div className="p-4 flex-1 overflow-y-auto">
      <h3 className="text-sm font-semibold text-gray-300 mb-2">Commands</h3>
      <div className="space-y-2 text-xs">
        <div className="bg-gray-800 rounded p-2">
          <code className="text-primary">/join &lt;room&gt;</code>
          <p className="text-gray-400 mt-1">Join a specific chatroom</p>
        </div>
        <div className="bg-gray-800 rounded p-2">
          <code className="text-primary">/translate &lt;username&gt;</code>
          <p className="text-gray-400 mt-1">Translate user messages to Hinglish</p>
        </div>
        <div className="bg-gray-800 rounded p-2">
          <code className="text-primary">/offtranslate &lt;username&gt;</code>
          <p className="text-gray-400 mt-1">Stop translating user messages</p>
        </div>
        <div className="bg-gray-800 rounded p-2">
          <code className="text-primary">kamina &lt;question&gt;</code>
          <p className="text-gray-400 mt-1">Ask anything to the bot</p>
        </div>
        <div className="bg-gray-800 rounded p-2">
          <code className="text-primary">Generate an image of &lt;prompt&gt;</code>
          <p className="text-gray-400 mt-1">Generate an image using AI</p>
        </div>
      </div>
    </div>
  );
}
