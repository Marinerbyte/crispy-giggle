import { BotState, BotActions } from "@/types";
import { Header } from "./header";
import { Sidebar } from "./sidebar";
import { ChatArea } from "./chat-area";
import { LogPanel } from "./log-panel";
import { useState } from "react";

interface DashboardProps {
  botState: BotState;
  botActions: BotActions;
}

export function Dashboard({ botState, botActions }: DashboardProps) {
  const [message, setMessage] = useState("");
  
  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      botActions.sendMessage(message);
      setMessage("");
    }
  };
  
  return (
    <div className="flex flex-col h-screen max-h-screen overflow-hidden bg-dark text-light">
      <Header 
        connected={botState.connected} 
      />
      
      <div className="flex flex-col md:flex-row flex-1 overflow-hidden">
        <Sidebar 
          botState={botState} 
          botActions={botActions}
        />
        
        <ChatArea 
          messages={botState.messages} 
          room={botState.room}
          userCount={botState.users.length}
          message={message}
          setMessage={setMessage}
          handleSendMessage={handleSendMessage}
        />
        
        <LogPanel 
          logs={botState.log} 
          errors={botState.errors}
          clearLogs={botActions.clearLogs}
          clearErrors={botActions.clearErrors}
        />
      </div>
    </div>
  );
}
