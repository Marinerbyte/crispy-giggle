import { Message } from "@/types";
import { useRef, useEffect } from "react";

interface ChatAreaProps {
  messages: Message[];
  room: string;
  userCount: number;
  message: string;
  setMessage: (message: string) => void;
  handleSendMessage: (e: React.FormEvent) => void;
}

export function ChatArea({ 
  messages, 
  room, 
  userCount, 
  message, 
  setMessage, 
  handleSendMessage 
}: ChatAreaProps) {
  const messageContainerRef = useRef<HTMLDivElement>(null);
  
  // Auto-scroll to bottom when new messages come in
  useEffect(() => {
    if (messageContainerRef.current) {
      messageContainerRef.current.scrollTop = messageContainerRef.current.scrollHeight;
    }
  }, [messages]);
  
  return (
    <div className="flex-1 flex flex-col bg-gray-900 overflow-hidden">
      {/* Chat Header */}
      <div className="bg-darker py-3 px-4 border-b border-gray-700 flex justify-between items-center">
        <div className="flex items-center">
          <span className="text-white font-medium">{room}</span>
          <span className="ml-2 text-xs bg-gray-700 text-gray-300 px-2 py-0.5 rounded-full">{userCount} users</span>
        </div>
        <div className="flex space-x-2">
          <button className="text-gray-400 hover:text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M5 4a1 1 0 00-2 0v7.268a2 2 0 000 3.464V16a1 1 0 102 0v-1.268a2 2 0 000-3.464V4zM11 4a1 1 0 10-2 0v1.268a2 2 0 000 3.464V16a1 1 0 102 0V8.732a2 2 0 000-3.464V4zM16 3a1 1 0 011 1v7.268a2 2 0 010 3.464V16a1 1 0 11-2 0v-1.268a2 2 0 010-3.464V4a1 1 0 011-1z" />
            </svg>
          </button>
          <button className="text-gray-400 hover:text-white">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
          </button>
        </div>
      </div>

      {/* Message List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4" ref={messageContainerRef}>
        {messages.map((msg) => (
          <div key={msg.id} className="flex items-start">
            {msg.type === "system" ? (
              <>
                <div className="flex-shrink-0 bg-gray-700 rounded p-2 text-gray-300 text-xs">
                  SYSTEM
                </div>
                <div className="ml-3 bg-gray-800 rounded-lg p-3 max-w-xs sm:max-w-md">
                  <p className="text-sm text-gray-300">{msg.text}</p>
                  <span className="text-xs text-gray-500 mt-1 block">{msg.timestamp}</span>
                </div>
              </>
            ) : (
              <>
                <div className={`flex-shrink-0 ${msg.sender === "Kamina Bot" ? "bg-primary" : "bg-blue-600"} rounded-full h-8 w-8 flex items-center justify-center`}>
                  <span className="text-white text-sm font-medium">{msg.sender && msg.sender.charAt(0) || "?"}</span>
                </div>
                <div className="ml-3 bg-gray-800 rounded-lg p-3 max-w-xs sm:max-w-md">
                  <p className="text-xs text-gray-400 mb-1">{msg.sender}</p>
                  <p className="text-sm text-white">{msg.text}</p>
                  {msg.imageUrl && (
                    <img src={msg.imageUrl} alt="Generated" className="rounded-md w-full mt-2" />
                  )}
                  <span className="text-xs text-gray-500 mt-1 block">{msg.timestamp}</span>
                </div>
              </>
            )}
          </div>
        ))}

        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <div className="text-gray-500 text-center">
              <p>No messages yet</p>
              <p className="text-xs mt-1">Start the conversation by sending a message</p>
            </div>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-darker border-t border-gray-700 p-4">
        <form onSubmit={handleSendMessage}>
          <div className="flex items-center">
            <input 
              type="text" 
              placeholder="Type a message..." 
              className="flex-1 bg-gray-800 border border-gray-700 rounded-l-lg px-4 py-2 text-white focus:outline-none focus:ring-1 focus:ring-primary"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
            <button 
              type="submit"
              className="bg-primary hover:bg-blue-600 text-white px-4 py-2 rounded-r-lg"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-8.707l-3-3a1 1 0 00-1.414 0l-3 3a1 1 0 001.414 1.414L9 9.414V13a1 1 0 102 0V9.414l1.293 1.293a1 1 0 001.414-1.414z" clipRule="evenodd" />
              </svg>
            </button>
          </div>
        </form>
        <div className="flex justify-between mt-2 text-xs text-gray-400">
          <div className="flex space-x-3">
            <button className="hover:text-white flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
              </svg>
              Image
            </button>
            <button className="hover:text-white flex items-center">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
              </svg>
              Audio
            </button>
          </div>
          <div>
            <span>Terminal mode</span>
            <input type="checkbox" className="ml-2 align-middle" defaultChecked />
          </div>
        </div>
      </div>
    </div>
  );
}
