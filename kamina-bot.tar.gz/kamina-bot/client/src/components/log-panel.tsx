import { LogEntry } from "@/types";

interface LogPanelProps {
  logs: LogEntry[];
  errors: string[];
  clearLogs: () => void;
  clearErrors: () => void;
}

export function LogPanel({ logs, errors, clearLogs, clearErrors }: LogPanelProps) {
  const getLogColorClass = (level: LogEntry["level"]) => {
    switch (level) {
      case "info": return "text-gray-400";
      case "success": return "text-green-400";
      case "warning": return "text-yellow-400";
      case "error": return "text-red-400";
      default: return "text-gray-400";
    }
  };
  
  return (
    <div className="hidden lg:block w-80 bg-darker border-l border-gray-700 flex flex-col">
      <div className="p-4 border-b border-gray-700 flex justify-between items-center">
        <h3 className="font-semibold text-white">Logs</h3>
        <div className="flex space-x-2">
          <button 
            className="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded hover:bg-gray-600"
            onClick={clearLogs}
          >
            Clear
          </button>
          <button 
            className="text-xs bg-primary text-white px-2 py-1 rounded hover:bg-blue-600"
            onClick={() => {
              const logText = logs.map(log => `[${log.timestamp}] ${log.text}`).join('\n');
              navigator.clipboard.writeText(logText);
            }}
          >
            Copy
          </button>
        </div>
      </div>
      
      <div className="flex-1 overflow-y-auto p-4 font-mono text-xs space-y-2 terminal-text">
        {logs.length > 0 ? (
          logs.map(log => (
            <div key={log.id} className={getLogColorClass(log.level)}>
              [{log.timestamp}] {log.text}
            </div>
          ))
        ) : (
          <div className="text-gray-500">No logs yet</div>
        )}
      </div>
      
      {/* Error Panel */}
      <div className="border-t border-gray-700 p-4">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-sm font-semibold text-gray-300">Errors</h3>
          {errors.length === 0 ? (
            <span className="text-xs bg-green-800 text-green-300 px-2 py-0.5 rounded">All Systems Normal</span>
          ) : (
            <span className="text-xs bg-red-800 text-red-300 px-2 py-0.5 rounded">{errors.length} Error(s)</span>
          )}
        </div>
        <div className="bg-gray-900 rounded-lg p-3 text-xs cursor flex">
          {errors.length === 0 ? (
            <span className="text-gray-500">No errors to display</span>
          ) : (
            <div className="text-red-400 space-y-2">
              {errors.map((error, index) => (
                <div key={index}>{error}</div>
              ))}
              <button 
                className="text-xs bg-gray-800 text-gray-300 px-2 py-1 rounded hover:bg-gray-700 mt-2"
                onClick={clearErrors}
              >
                Clear Errors
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
