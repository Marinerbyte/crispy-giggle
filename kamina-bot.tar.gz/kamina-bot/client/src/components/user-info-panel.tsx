import { useState } from "react";

interface UserInfoPanelProps {
  lookupUser: (username: string) => void;
  translateUser?: (username: string) => void;
  stopTranslatingUser?: (username: string) => void;
  translatedUsers?: string[];
}

export function UserInfoPanel({ 
  lookupUser, 
  translateUser, 
  stopTranslatingUser,
  translatedUsers = [] 
}: UserInfoPanelProps) {
  const [username, setUsername] = useState("");
  const [selectedUser, setSelectedUser] = useState<string | null>(null);
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (username.trim()) {
      lookupUser(username);
      setSelectedUser(username);
    }
  };
  
  const handleTranslateToggle = () => {
    if (!selectedUser) return;
    
    if (isTranslated && stopTranslatingUser) {
      console.log("Stopping translation for user:", selectedUser);
      stopTranslatingUser(selectedUser);
    } else if (translateUser) {
      console.log("Starting translation for user:", selectedUser);
      translateUser(selectedUser);
    }
    // UI will be updated by the parent component via WebSocket
  };
  
  const isTranslated = selectedUser ? translatedUsers.includes(selectedUser) : false;
  
  return (
    <div className="p-4 border-b border-gray-700">
      <h3 className="text-sm font-semibold text-gray-300 mb-2">User Lookup</h3>
      <form onSubmit={handleSubmit} className="flex mb-3">
        <input 
          type="text" 
          placeholder="Enter username" 
          className="w-full bg-gray-800 border border-gray-700 rounded-l px-3 py-2 text-sm focus:outline-none focus:ring-1 focus:ring-primary text-white"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <button 
          type="submit"
          className="bg-primary hover:bg-blue-600 text-white px-3 rounded-r"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
        </button>
      </form>
      
      {selectedUser ? (
        <div className="bg-gray-800 rounded p-3">
          <div className="flex justify-between items-center mb-2">
            <span className="text-white text-sm font-medium">{selectedUser}</span>
            
            {translateUser && (
              <button
                onClick={handleTranslateToggle}
                className={`text-xs px-2 py-1 rounded ${isTranslated
                  ? 'bg-red-500 hover:bg-red-600 text-white'
                  : 'bg-green-600 hover:bg-green-700 text-white'
                }`}
              >
                {isTranslated ? 'Stop Translating' : 'Translate'}
              </button>
            )}
          </div>
          <div className="text-xs text-gray-400 bg-gray-900 p-2 rounded">
            User found. Click to translate their messages.
          </div>
        </div>
      ) : (
        <div className="bg-gray-800 rounded p-2 text-xs text-gray-400">
          No user selected
        </div>
      )}
    </div>
  );
}
