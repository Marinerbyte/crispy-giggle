interface HeaderProps {
  connected: boolean;
}

export function Header({ connected }: HeaderProps) {
  return (
    <header className="bg-darker py-3 px-4 flex items-center justify-between border-b border-gray-700">
      <div className="flex items-center space-x-2">
        <div className="w-3 h-3 rounded-full bg-red-500"></div>
        <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
        <div className="w-3 h-3 rounded-full bg-green-500"></div>
        <h1 className="text-xl font-bold ml-2">Kamina Bot <span className="text-xs bg-primary text-white px-2 py-0.5 rounded">v1.0</span></h1>
      </div>
      <div className="flex items-center">
        <div className={`${connected ? 'bg-green-500' : 'bg-red-500'} w-2 h-2 rounded-full mr-2`}></div>
        <span className={`text-sm ${connected ? 'text-green-400' : 'text-red-400'}`}>
          {connected ? 'Connected' : 'Disconnected'}
        </span>
      </div>
    </header>
  );
}
