interface StatusCardProps {
  connected: boolean;
  room: string;
}

export function StatusCard({ connected, room }: StatusCardProps) {
  return (
    <div className="p-4 border-b border-gray-700">
      <div className="bg-dark rounded-lg p-3">
        <div className="flex items-center mb-2">
          <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center text-white font-bold">K</div>
          <div className="ml-3">
            <h3 className="font-semibold text-white">Kamina Bot</h3>
            <p className="text-xs text-gray-400">Master: Yasin</p>
          </div>
        </div>
        <div className="flex items-center text-xs mt-2">
          <span className={`inline-block w-2 h-2 rounded-full ${connected ? 'bg-green-500' : 'bg-red-500'} mr-2`}></span>
          <span className={connected ? 'text-green-400' : 'text-red-400'}>
            {connected ? 'Online' : 'Offline'}
          </span>
          <span className="mx-2 text-gray-600">|</span>
          <span className="text-gray-400">Room: {room}</span>
        </div>
      </div>
    </div>
  );
}
