// This file contains the client-side bot integration.
// It supports the communication between the frontend UI and the backend bot service.

import { apiRequest } from "@/lib/queryClient";

/**
 * Makes a request to start the bot service if it's not already running
 */
export async function startBot() {
  try {
    const response = await apiRequest("POST", "/api/bot/start", {});
    return response.ok;
  } catch (error) {
    console.error("Failed to start bot:", error);
    return false;
  }
}

/**
 * Makes a request to stop the bot service
 */
export async function stopBot() {
  try {
    const response = await apiRequest("POST", "/api/bot/stop", {});
    return response.ok;
  } catch (error) {
    console.error("Failed to stop bot:", error);
    return false;
  }
}

/**
 * Makes a request to get the current status of the bot
 */
export async function getBotStatus() {
  try {
    const response = await apiRequest("GET", "/api/bot/status", undefined);
    return await response.json();
  } catch (error) {
    console.error("Failed to get bot status:", error);
    return { connected: false, room: null };
  }
}

/**
 * Makes a request to the bot to send a message to the current room
 */
export async function sendBotMessage(message: string) {
  try {
    const response = await apiRequest("POST", "/api/bot/message", { text: message });
    return response.ok;
  } catch (error) {
    console.error("Failed to send message:", error);
    return false;
  }
}

/**
 * Makes a request to the bot to join a specific room
 */
export async function joinRoom(roomName: string) {
  try {
    const response = await apiRequest("POST", "/api/bot/join", { roomName });
    return response.ok;
  } catch (error) {
    console.error("Failed to join room:", error);
    return false;
  }
}

/**
 * Makes a request to enable translation for a specific user
 */
export async function enableTranslation(username: string) {
  try {
    const response = await apiRequest("POST", "/api/bot/translate", { username });
    return response.ok;
  } catch (error) {
    console.error("Failed to enable translation:", error);
    return false;
  }
}

/**
 * Makes a request to disable translation for a specific user
 */
export async function disableTranslation(username: string) {
  try {
    const response = await apiRequest("POST", "/api/bot/offtranslate", { username });
    return response.ok;
  } catch (error) {
    console.error("Failed to disable translation:", error);
    return false;
  }
}
