import { Dashboard } from "@/components/dashboard";
import { useBotState } from "@/hooks/use-bot-state";

export default function Home() {
  const [botState, botActions] = useBotState();
  
  return (
    <Dashboard botState={botState} botActions={botActions} />
  );
}
