export interface Message {
  id: string;
  sender: string;
  text: string;
  timestamp: string;
  type: "text" | "image" | "system";
  avatar?: string;
  imageUrl?: string;
}

export interface User {
  username: string;
  avatar?: string;
  isOnline?: boolean;
}

export interface Room {
  name: string;
  userCount: number;
  messageCount: number;
  activeUsers: number;
}

export interface BotState {
  connected: boolean;
  room: string;
  messages: Message[];
  users: User[];
  log: LogEntry[];
  errors: string[];
  translatedUsers: string[];
}

export interface LogEntry {
  id: string;
  timestamp: string;
  text: string;
  level: "info" | "error" | "warning" | "success";
}

export interface BotActions {
  sendMessage: (text: string) => void;
  joinRoom: (roomName: string) => void;
  lookupUser: (username: string) => void;
  clearLogs: () => void;
  clearErrors: () => void;
  translateUser: (username: string) => void;
  stopTranslatingUser: (username: string) => void;
}
