import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add title to the document
document.title = "Kamina Bot - Howdies Chat Bot";

// Add meta tags for better SEO
const metaDescription = document.createElement("meta");
metaDescription.name = "description";
metaDescription.content = "Kamina Bot for Howdies chat platform with AI integration using Gemini API";
document.head.appendChild(metaDescription);

// Add font
const fontLink = document.createElement("link");
fontLink.href = "https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap";
fontLink.rel = "stylesheet";
document.head.appendChild(fontLink);

createRoot(document.getElementById("root")!).render(<App />);
