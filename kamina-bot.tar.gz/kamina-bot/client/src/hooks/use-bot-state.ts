import { useState, useEffect, useCallback } from "react";
import { BotState, BotActions, Message, LogEntry } from "@/types";
import { v4 as uuidv4 } from "uuid";

export function useBotState(): [BotState, BotActions] {
  const [state, setState] = useState<BotState>({
    connected: false,
    room: "🏏Atlanta🏏",
    messages: [],
    users: [],
    log: [],
    errors: [],
    translatedUsers: [],
  });

  const addLogEntry = useCallback((text: string, level: LogEntry["level"] = "info") => {
    const now = new Date();
    const timestamp = now.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    });
    
    setState(prev => ({
      ...prev,
      log: [
        ...prev.log, 
        { id: uuidv4(), timestamp, text, level }
      ]
    }));
  }, []);

  const addMessage = useCallback((message: Omit<Message, "id" | "timestamp">) => {
    const now = new Date();
    const timestamp = now.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      hour12: true,
    });
    
    setState(prev => ({
      ...prev,
      messages: [
        ...prev.messages,
        { ...message, id: uuidv4(), timestamp }
      ]
    }));
  }, []);

  // WebSocket connection
  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/api/ws`;
    console.log("Connecting to WebSocket:", wsUrl);
    
    // Add initial log entry
    addLogEntry("Connecting to server...", "info");
    
    // Create WebSocket connection
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      setState(prev => ({ ...prev, connected: true }));
      addLogEntry("Connected to WebSocket server", "success");
      
      // Add system message for joining
      addMessage({
        sender: "SYSTEM",
        text: "Bot is connected and ready",
        type: "system"
      });
    };

    socket.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        
        if (data.type === "status") {
          setState(prev => ({
            ...prev,
            connected: data.connected,
            room: data.room || prev.room
          }));
        } 
        else if (data.type === "message") {
          addMessage({
            sender: data.sender || "Unknown",
            text: data.text || "",
            type: data.messageType || "text",
            imageUrl: data.imageUrl
          });
          
          if (data.sender && data.text) {
            addLogEntry(`Received message from ${data.sender}: "${data.text.substring(0, 30)}${data.text.length > 30 ? '...' : ''}"`, 
              data.messageType === "system" ? "info" : "success");
          }
        }
        else if (data.type === "log") {
          addLogEntry(data.text || "Empty log message", data.level || "info");
        }
        else if (data.type === "users") {
          setState(prev => ({
            ...prev,
            users: data.users || []
          }));
          addLogEntry(`User list updated: ${(data.users || []).length} users`);
        }
        else if (data.type === "error") {
          setState(prev => ({
            ...prev,
            errors: [...prev.errors, data.text || "Unknown error"]
          }));
          addLogEntry(data.text || "Unknown error", "error");
        }
        else if (data.type === "translate") {
          setState(prev => ({
            ...prev,
            translatedUsers: [...prev.translatedUsers, data.username]
          }));
          addLogEntry(`Translation enabled for user: ${data.username}`);
          
          addMessage({
            sender: "SYSTEM",
            text: `Translation enabled for user: ${data.username}`,
            type: "system"
          });
        }
        else if (data.type === "offtranslate") {
          setState(prev => ({
            ...prev,
            translatedUsers: prev.translatedUsers.filter(u => u !== data.username)
          }));
          addLogEntry(`Translation disabled for user: ${data.username}`);
          
          addMessage({
            sender: "SYSTEM",
            text: `Translation disabled for user: ${data.username}`,
            type: "system"
          });
        }
      } catch (err) {
        console.error("Error parsing WebSocket message", err);
      }
    };

    socket.onclose = () => {
      setState(prev => ({ ...prev, connected: false }));
      addLogEntry("Disconnected from WebSocket server", "error");
    };

    socket.onerror = (error) => {
      setState(prev => ({ ...prev, connected: false }));
      addLogEntry(`WebSocket error: ${error}`, "error");
    };

    return () => {
      socket.close();
    };
  }, [addLogEntry, addMessage]);

  // Define bot actions
  const actions: BotActions = {
    sendMessage: (text) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      const socket = new WebSocket(wsUrl);
      
      // Optimistically add message
      addMessage({
        sender: "You",
        text,
        type: "text"
      });
      
      addLogEntry(`Sending message: "${text.substring(0, 30)}${text.length > 30 ? '...' : ''}"`);
      
      socket.onopen = () => {
        try {
          socket.send(JSON.stringify({
            type: "message",
            text
          }));
          addLogEntry(`Message sent successfully`, "success");
        } catch (error) {
          console.error("Error sending message:", error);
          addLogEntry(`Failed to send message: ${error}`, "error");
        } finally {
          socket.close();
        }
      };
      
      socket.onerror = (error) => {
        console.error("WebSocket error during send:", error);
        addLogEntry(`WebSocket error during send: ${error}`, "error");
      };
    },
    
    joinRoom: (roomName) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        socket.send(JSON.stringify({
          type: "join",
          room: roomName
        }));
        socket.close();
      };
      
      addLogEntry(`Requesting to join room: ${roomName}`);
    },
    
    lookupUser: (username) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      const socket = new WebSocket(wsUrl);
      
      socket.onopen = () => {
        socket.send(JSON.stringify({
          type: "lookup",
          username
        }));
        socket.close();
      };
      
      addLogEntry(`Looking up user: ${username}`);
    },
    
    clearLogs: () => {
      setState(prev => ({ ...prev, log: [] }));
    },
    
    clearErrors: () => {
      setState(prev => ({ ...prev, errors: [] }));
    },
    
    translateUser: (username) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      console.log("Connecting to WebSocket for translation:", wsUrl);
      const socket = new WebSocket(wsUrl);
      
      // Optimistically update UI first
      setState(prev => ({
        ...prev,
        translatedUsers: [...prev.translatedUsers.filter(u => u !== username), username]
      }));
      
      addLogEntry(`Requesting translation for user: ${username}`);
      
      socket.onopen = () => {
        try {
          console.log("Sending translation request for:", username);
          
          socket.send(JSON.stringify({
            type: "translate",
            username
          }));
          
          addLogEntry(`Translation request sent for: ${username}`, "success");
          
          // Add system message for confirmation
          addMessage({
            sender: "SYSTEM",
            text: `Translation requested for user: ${username}`,
            type: "system"
          });
        } catch (error) {
          console.error("Error enabling translation:", error);
          addLogEntry(`Failed to enable translation: ${error}`, "error");
          
          // Revert the optimistic UI update
          setState(prev => ({
            ...prev,
            translatedUsers: prev.translatedUsers.filter(u => u !== username)
          }));
        } finally {
          socket.close();
        }
      };
      
      socket.onerror = (error) => {
        console.error("WebSocket error during translation request:", error);
        addLogEntry(`WebSocket error during translation request: ${error}`, "error");
        
        // Revert the optimistic UI update
        setState(prev => ({
          ...prev,
          translatedUsers: prev.translatedUsers.filter(u => u !== username)
        }));
      };
    },
    
    stopTranslatingUser: (username) => {
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/ws`;
      console.log("Connecting to WebSocket to stop translation:", wsUrl);
      const socket = new WebSocket(wsUrl);
      
      // Optimistically update UI first
      setState(prev => ({
        ...prev,
        translatedUsers: prev.translatedUsers.filter(u => u !== username)
      }));
      
      addLogEntry(`Requesting to stop translation for user: ${username}`);
      
      socket.onopen = () => {
        try {
          console.log("Sending request to stop translation for:", username);
          
          socket.send(JSON.stringify({
            type: "offtranslate",
            username
          }));
          
          addLogEntry(`Request sent to stop translation for: ${username}`, "success");
          
          // Add system message for confirmation
          addMessage({
            sender: "SYSTEM",
            text: `Translation disabled for user: ${username}`,
            type: "system"
          });
        } catch (error) {
          console.error("Error disabling translation:", error);
          addLogEntry(`Failed to disable translation: ${error}`, "error");
          
          // Revert the optimistic UI update
          setState(prev => ({
            ...prev,
            translatedUsers: [...prev.translatedUsers, username]
          }));
        } finally {
          socket.close();
        }
      };
      
      socket.onerror = (error) => {
        console.error("WebSocket error when stopping translation:", error);
        addLogEntry(`WebSocket error when stopping translation: ${error}`, "error");
        
        // Revert the optimistic UI update
        setState(prev => ({
          ...prev,
          translatedUsers: [...prev.translatedUsers, username]
        }));
      };
    }
  };

  return [state, actions];
}
