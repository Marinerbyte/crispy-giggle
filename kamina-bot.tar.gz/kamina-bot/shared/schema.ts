import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Messages table to store chat messages
export const messages = pgTable("messages", {
  id: serial("id").primaryKey(),
  sender: text("sender").notNull(),
  text: text("text").notNull(),
  type: text("type").notNull().default("text"),
  imageUrl: text("image_url"),
  roomId: text("room_id").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Translated Users table to store which users have translation enabled
export const translatedUsers = pgTable("translated_users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Bot Config table for storing bot configuration
export const botConfig = pgTable("bot_config", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Logs table for storing bot activity logs
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  text: text("text").notNull(),
  level: text("level").notNull().default("info"),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
});

// Define relationships
export const usersRelations = relations(users, ({ many }) => ({
  messages: many(messages),
}));

export const messagesRelations = relations(messages, ({ one }) => ({
  sender: one(users, {
    fields: [messages.sender],
    references: [users.username],
  }),
}));

// Create schemas for insertion
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertMessageSchema = createInsertSchema(messages).pick({
  sender: true,
  text: true,
  type: true,
  imageUrl: true,
  roomId: true,
});

export const insertTranslatedUserSchema = createInsertSchema(translatedUsers).pick({
  username: true,
  enabled: true,
});

export const insertLogSchema = createInsertSchema(logs).pick({
  text: true,
  level: true,
});

export const insertBotConfigSchema = createInsertSchema(botConfig).pick({
  key: true,
  value: true,
});

// Export types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertMessage = z.infer<typeof insertMessageSchema>;
export type InsertTranslatedUser = z.infer<typeof insertTranslatedUserSchema>;
export type InsertLog = z.infer<typeof insertLogSchema>;
export type InsertBotConfig = z.infer<typeof insertBotConfigSchema>;

export type User = typeof users.$inferSelect;
export type Message = typeof messages.$inferSelect;
export type TranslatedUser = typeof translatedUsers.$inferSelect;
export type Log = typeof logs.$inferSelect;
export type BotConfig = typeof botConfig.$inferSelect;
