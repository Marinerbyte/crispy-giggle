import websocket
import json
import requests
import threading
import time
import random
import os
from dotenv import load_dotenv

try:
    import yt_dlp
except ImportError:
    print("yt_dlp not installed. Installing...")
    os.system("pip install yt-dlp")

# Load environment variables securely
load_dotenv()
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY")
HUGGINGFACE_API_KEY = os.getenv("HUGGINGFACE_API_KEY")
if not GEMINI_API_KEY:
    raise ValueError("GEMINI_API_KEY not found in .env!")
if not HUGGINGFACE_API_KEY:
    print("Warning: HUGGINGFACE_API_KEY not found. Image generation disabled.")

# Bot configuration
BOT_USERNAME = "kamina"
BOT_PASSWORD = "p99665"
MASTER_USER = "yasin"
DEFAULT_ROOM = "🏏Atlanta🏏"
RECONNECT_DELAY = 15  # Slow reconnect
MAX_RECONNECT_ATTEMPTS = 3  # Limited attempts
CAPTCHA_TIMEOUT = 45  # Wait for captcha response
DM_COOLDOWN = 30  # Cooldown for DMs (seconds)
BOT_NAME = "kamina"

# Gemini API
GEMINI_API_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent"

# Hugging Face Stable Diffusion
HF_API_URL = "https://api-inference.huggingface.co/models/stabilityai/stable-diffusion-2-1"

# Howdies API
LOGIN_URL = "https://api.howdies.app/api/login"
WS_URL = "wss://app.howdies.app/"
UPLOAD_URL = "https://api.howdies.app/api/upload"

# Game state
game_state = {
    "score_predictor": {"is_running": False, "predictions": {}, "actual_runs": None},
    "emoji_story": {"is_running": False, "theme": None, "story_parts": [], "best_contributor": None},
    "is_muted": False
}

# Captcha state
captcha_state = {"pending": False, "captcha_url": None, "target_user": None, "target_room": None, "last_attempt": 0}

# Translation state
translate_users = {}

# User list
user_list = []

# Global variables
token = None
current_room = DEFAULT_ROOM
ws_instance = None
last_dm_time = 0  # Track last DM to avoid spam

def get_gemini_response(prompt, context=""):
    """Get text response from Gemini API."""
    try:
        headers = {"Content-Type": "application/json"}
        payload = {"contents": [{"parts": [{"text": f"{context}\n{prompt}"}]}]}
        response = requests.post(
            f"{GEMINI_API_URL}?key={GEMINI_API_KEY}",
            headers=headers,
            json=payload,
            verify=True
        )
        print(f"Gemini API response: {response.status_code}")
        if response.status_code == 200:
            return response.json()["candidates"][0]["content"]["parts"][0]["text"]
        return "API se response nahi aaya!"
    except Exception as e:
        print(f"Gemini API error: {e}")
        return "AI down hai, baad mein try kar!"

def translate_to_hinglish(message):
    """Translate message to Hinglish using Gemini."""
    try:
        context = f"Translate this message to Hinglish (Hindi-English mix, casual tone): {message}"
        translated = get_gemini_response("Translate to Hinglish", context)
        return translated
    except Exception as e:
        print(f"Translation error: {e}")
        return "Translation failed!"

def get_hf_image(prompt):
    """Generate image using Hugging Face Stable Diffusion."""
    if not HUGGINGFACE_API_KEY:
        return None, "Hugging Face API key not set!"
    try:
        headers = {"Authorization": f"Bearer {HUGGINGFACE_API_KEY}"}
        payload = {"inputs": prompt}
        response = requests.post(HF_API_URL, headers=headers, json=payload, verify=True)
        print(f"Hugging Face API response: {response.status_code}")
        if response.status_code == 200:
            image_path = f"image_{random.randint(1, 10000)}.png"
            with open(image_path, "wb") as f:
                f.write(response.content)
            return image_path, None
        return None, "Image generation failed!"
    except Exception as e:
        print(f"Hugging Face API error: {e}")
        return None, "Image generation error!"

def upload_file(filename, is_image=False):
    """Upload file (song or image) to Howdies."""
    try:
        print(f"Uploading file: {filename}")
        with open(filename, 'rb') as f:
            mime_type = 'image/png' if is_image else 'audio/mpeg'
            files = {'file': (filename, f, mime_type)}
            headers = {'Authorization': f'Bearer {token}'}
            response = requests.post(UPLOAD_URL, files=files, headers=headers, verify=True)
            print(f"Upload response: {response.status_code} {response.text}")
            if response.status_code == 200:
                data = response.json()
                file_id = data.get('file_id') or data.get('id') or data.get('file')
                if file_id:
                    print(f"Uploaded successfully. File ID: {file_id}")
                    return file_id
                return None
            return None
    except Exception as e:
        print(f"Upload error: {e}")
        return None

def get_token(captcha_token=None):
    """Fetch Howdies auth token."""
    payload = {"username": BOT_USERNAME, "password": BOT_PASSWORD}
    if captcha_token:
        payload["captcha_token"] = captcha_token
    try:
        response = requests.post(LOGIN_URL, json=payload, verify=True)
        print(f"Login response: {response.status_code} {response.text}")
        if response.status_code == 200:
            return response.json().get("token"), None
        elif response.status_code == 429:
            print("Rate limit hit on login API!")
            return None, "rate_limit"
        elif "captcha" in response.text.lower():
            data = response.json()
            captcha_url = data.get("captcha_url")
            return None, captcha_url
        return None, None
    except Exception as e:
        print(f"Login error: {e}")
        return None, None

def send_ws_message(ws, payload, allow_dm=True):
    """Send WebSocket message with DM cooldown."""
    global last_dm_time
    try:
        ws.send(json.dumps(payload))
        print(f"Sent WebSocket message: {payload}")
        if allow_dm and payload.get("handler") == "message" and time.time() - last_dm_time > DM_COOLDOWN:
            last_dm_time = time.time()
            ws.send(json.dumps(payload))
    except Exception as e:
        print(f"WebSocket send error: {e}")

def join_room(ws, room_name, attempt=1, max_attempts=3):
    """Join Howdies chatroom with retry."""
    global current_room, user_list
    payload = {"handler": "joinchatroom", "name": room_name, "roomPassword": ""}
    send_ws_message(ws, payload, allow_dm=False)
    current_room = room_name
    user_list = []
    print(f"Attempting to join room: {room_name} (Attempt {attempt}/{max_attempts})")
    send_ws_message(ws, {
        "handler": "message",
        "type": "text",
        "to": MASTER_USER,
        "text": f"Joining room: {room_name} (Attempt {attempt})"
    })

def download_song(song_name, retries=2):
    """Download song from YouTube."""
    for attempt in range(retries):
        try:
            print(f"Downloading song: {song_name} (Attempt {attempt + 1}/{retries})")
            ydl_opts = {
                'format': 'bestaudio/best',
                'outtmpl': f'song_{random.randint(1, 10000)}.%(ext)s',
                'postprocessors': [{'key': 'FFmpegExtractAudio', 'preferredcodec': 'mp3', 'preferredquality': '192'}],
                'quiet': True,
                'no_warnings': True,
                'noplaylist': True,
            }
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(f"ytsearch:{song_name}", download=True)
                if 'entries' in info and info['entries']:
                    title = info['entries'][0]['title']
                    filename = next((f for f in os.listdir('.') if f.startswith('song_') and f.endswith('.mp3')), None)
                    if filename:
                        print(f"Downloaded: {title} -> {filename}")
                        return filename, title
                return None, None
        except Exception as e:
            print(f"Download error: {e}")
            if attempt < retries - 1:
                time.sleep(2)
            else:
                return None, None

def process_command(ws, sender, message, is_dm=False):
    """Process commands with Gemini, Hugging Face, and translation."""
    global current_room, user_list, translate_users

    # Handle bot commands first (highest priority)
    if message.lower().startswith("/join ") and sender.lower() == MASTER_USER.lower():
        try:
            room_name = " ".join(message.split()[1:]).strip()
            if not room_name:
                raise ValueError("Room name cannot be empty!")
            join_room(ws, room_name)
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": f"Attempting to join room: {room_name}"
            })
            return  # Stop further processing
        except ValueError as e:
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": f"Error: {str(e)} Use /join <room name>"
            })
            return

    if message.lower().startswith("/translate "):
        try:
            target_user = message.split()[1].strip()
            if target_user == BOT_USERNAME:
                send_ws_message(ws, {
                    "handler": "chatroommessage" if not is_dm else "message",
                    "type": "text",
                    "roomid": current_room if not is_dm else None,
                    "to": sender if is_dm else None,
                    "text": "Bot ke messages translate nahi kar sakta!"
                })
                return
            translate_users[target_user] = True
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": f"Translating {target_user}'s messages to Hinglish!"
            })
            return
        except IndexError:
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": "Invalid command! Use /translate <username>"
            })
            return

    if message.lower().startswith("/offtranslate "):
        try:
            target_user = message.split()[1].strip()
            if target_user in translate_users:
                translate_users[target_user] = False
                send_ws_message(ws, {
                    "handler": "chatroommessage" if not is_dm else "message",
                    "type": "text",
                    "roomid": current_room if not is_dm else None,
                    "to": sender if is_dm else None,
                    "text": f"Stopped translating {target_user}'s messages."
                })
            else:
                send_ws_message(ws, {
                    "handler": "chatroommessage" if not is_dm else "message",
                    "type": "text",
                    "roomid": current_room if not is_dm else None,
                    "to": sender if is_dm else None,
                    "text": f"{target_user} ke liye translation on nahi tha!"
                })
            return
        except IndexError:
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": "Invalid command! Use /offtranslate <username>"
            })
            return

    if message.lower().startswith("/play"):
        try:
            song_name = " ".join(message.split()[1:]).strip()
            if not song_name:
                raise ValueError("Song name cannot be empty!")
            filename, title = download_song(song_name)
            if not filename or not title:
                raise ValueError("Failed to download song!")
            file_id = upload_file(filename, is_image=False)
            if file_id:
                send_ws_message(ws, {
                    "handler": "chatroommessage" if not is_dm else "message",
                    "type": "text",
                    "roomid": current_room if not is_dm else None,
                    "to": sender if is_dm else None,
                    "text": f"Playing '{title}' (File ID: {file_id})"
                })
                send_ws_message(ws, {
                    "handler": "playfile",
                    "roomid": current_room,
                    "file_id": file_id
                })
                if BOT_NAME.lower() in message.lower():
                    context = f"User in Howdies room requested song: {title}. Suggest a similar song casually."
                    ai_suggestion = get_gemini_response("Suggest a song", context)
                    send_ws_message(ws, {
                        "handler": "chatroommessage" if not is_dm else "message",
                        "type": "text",
                        "roomid": current_room if not is_dm else None,
                        "to": sender if is_dm else None,
                        "text": f"Suggestion: {ai_suggestion}"
                    })
            else:
                raise ValueError("Failed to upload song!")
            if os.path.exists(filename):
                os.remove(filename)
                print(f"Cleaned up file: {filename}")
            return
        except ValueError as e:
            error_msg = f"Error: {str(e)} Use /play <song name> (e.g., /play Perfect)"
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": error_msg
            })
            return

    if message.lower() == ".list":
        if not user_list:
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": "No users in the room or list not updated."
            })
        else:
            user_list_msg = "Users in room:\n" + "\n".join(f"{i+1}. {user}" for i, user in enumerate(user_list))
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": user_list_msg
            })
        return

    if sender.lower() == MASTER_USER.lower() and message.lower().startswith("kick "):
        try:
            target_user = message.split()[1].strip()
            send_ws_message(ws, {
                "handler": "kickuser",
                "roomid": current_room,
                "to": target_user
            })
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": f"{target_user} has been kicked!"
            })
            return
        except IndexError:
            send_ws_message(ws, {
                "handler": "chatroommessage" if not is_dm else "message",
                "type": "text",
                "roomid": current_room if not is_dm else None,
                "to": sender if is_dm else None,
                "text": "Invalid command! Use kick <username>"
            })
            return

    # Translation for users (after bot commands)
    if sender in translate_users and translate_users[sender]:
        translated = translate_to_hinglish(message)
        send_ws_message(ws, {
            "handler": "chatroommessage" if not is_dm else "message",
            "type": "text",
            "roomid": current_room if not is_dm else None,
            "to": sender if is_dm else None,
            "text": f"{sender}: {message} -> Hinglish: {translated}"
        })
        return

    # AI response for bot name mention (after bot commands and translation)
    if BOT_NAME.lower() in message.lower():
        # First check for image generation (Hugging Face)
        if any(keyword in message.lower() for keyword in ["photo", "image", "picture", "bana"]):
            prompt = message.replace(BOT_NAME, "").strip()
            context = f"User {sender} in Howdies room {current_room} wants an image: {prompt}"
            image_path, error = get_hf_image(prompt)
            if image_path:
                file_id = upload_file(image_path, is_image=True)
                if file_id:
                    send_ws_message(ws, {
                        "handler": "chatroommessage" if not is_dm else "message",
                        "type": "text",
                        "roomid": current_room if not is_dm else None,
                        "to": sender if is_dm else None,
                        "text": f"Generated image for '{prompt}' (File ID: {file_id})"
                    })
                    send_ws_message(ws, {
                        "handler": "playfile",
                        "roomid": current_room,
                        "file_id": file_id
                    })
                else:
                    send_ws_message(ws, {
                        "handler": "chatroommessage" if not is_dm else "message",
                        "type": "text",
                        "roomid": current_room if not is_dm else None,
                        "to": sender if is_dm else None,
                        "text": "Failed to upload image!"
                    })
                if os.path.exists(image_path):
                    os.remove(image_path)
                    print(f"Cleaned up file: {image_path}")
            else:
                send_ws_message(ws, {
                    "handler": "chatroommessage" if not is_dm else "message",
                    "type": "text",
                    "roomid": current_room if not is_dm else None,
                    "to": sender if is_dm else None,
                    "text": error or "Image generation failed!"
                })
            return  # Stop here, no Gemini response

        # If not image-related, use Gemini for general response
        context = f"User {sender} in Howdies room {current_room} mentions bot '{BOT_NAME}': {message}\nRespond casually in Hindi/English mix."
        ai_response = get_gemini_response(message, context)
        send_ws_message(ws, {
            "handler": "chatroommessage" if not is_dm else "message",
            "type": "text",
            "roomid": current_room if not is_dm else None,
            "to": sender if is_dm else None,
            "text": ai_response
        })
        return

def on_message(ws, message):
    """Handle WebSocket messages."""
    global captcha_state, user_list, current_room
    try:
        data = json.loads(message)
        handler = data.get("handler")
        print(f"Received WebSocket message: {data}")
        if handler == "chatroommessage":
            sender = data.get("username")
            text = data.get("text")
            if text and sender != BOT_USERNAME:
                print(f"[Chatroom] {sender}: {text}")
                if sender not in user_list:
                    user_list.append(sender)
                process_command(ws, sender, text, is_dm=False)
        elif handler == "message":
            sender = data.get("from")
            text = data.get("text")
            if text:
                print(f"[DM] {sender}: {text}")
                if captcha_state["pending"] and sender.lower() == MASTER_USER.lower():
                    captcha_state["pending"] = False
                    captcha_state["captcha_url"] = None
                    captcha_state["last_attempt"] = time.time()
                    new_token, captcha_url = get_token(captcha_token=text.strip())
                    if new_token:
                        global token
                        token = new_token
                        connect_websocket()
                    elif captcha_url:
                        captcha_state["pending"] = True
                        captcha_state["captcha_url"] = captcha_url
                        send_ws_message(ws, {
                            "handler": "message",
                            "type": "text",
                            "to": MASTER_USER,
                            "text": f"New captcha required: {captcha_url}"
                        })
                    elif captcha_url == "rate_limit":
                        send_ws_message(ws, {
                            "handler": "message",
                            "type": "text",
                            "to": MASTER_USER,
                            "text": "Rate limit hit on login. Waiting before retry..."
                        })
                        time.sleep(60)
                        connect_websocket()
                else:
                    process_command(ws, sender, text, is_dm=True)
        elif handler == "userjoined":
            username = data.get("username")
            if username and username != BOT_USERNAME and username not in user_list:
                user_list.append(username)
                print(f"User joined: {username}")
        elif handler == "userleft":
            username = data.get("username")
            if username and username in user_list:
                user_list.remove(username)
                print(f"User left: {username}")
        elif handler == "joinchatroom":
            if data.get("success"):
                print(f"Successfully joined room: {current_room}")
                send_ws_message(ws, {
                    "handler": "message",
                    "type": "text",
                    "to": MASTER_USER,
                    "text": f"Successfully joined room: {current_room}"
                })
            else:
                error_msg = data.get('error', 'Unknown error')
                print(f"Failed to join room: {error_msg}")
                if time.time() - last_dm_time > DM_COOLDOWN:
                    send_ws_message(ws, {
                        "handler": "message",
                        "type": "text",
                        "to": MASTER_USER,
                        "text": f"Failed to join room: {current_room}. Error: {error_msg}. Retrying..."
                    })
                if "rate_limit" in error_msg.lower():
                    time.sleep(60)
                time.sleep(2)
                if attempt < max_attempts:
                    join_room(ws, current_room, attempt=attempt + 1)
        elif handler == "error" and "captcha" in str(data).lower():
            captcha_url = data.get("captcha_url")
            if captcha_url and time.time() - captcha_state["last_attempt"] > DM_COOLDOWN:
                captcha_state["pending"] = True
                captcha_state["captcha_url"] = captcha_url
                captcha_state["target_user"] = MASTER_USER
                captcha_state["last_attempt"] = time.time()
                send_ws_message(ws, {
                    "handler": "message",
                    "type": "text",
                    "to": MASTER_USER,
                    "text": f"Captcha required! Open: {captcha_url}\nSend answer in DM."
                })
    except json.JSONDecodeError:
        print("Invalid JSON received:", message)

def on_error(ws, error):
    print(f"WebSocket error: {error}")
    if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
        send_ws_message(ws_instance, {
            "handler": "message",
            "type": "text",
            "to": MASTER_USER,
            "text": f"WebSocket error: {error}. Reconnecting..."
        })

def on_close(ws, close_status_code, close_msg):
    print(f"WebSocket closed: {close_msg}. Reconnecting in {RECONNECT_DELAY}s...")
    if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
        send_ws_message(ws_instance, {
            "handler": "message",
            "type": "text",
            "to": MASTER_USER,
            "text": f"WebSocket closed: {close_msg}. Reconnecting..."
        })
    time.sleep(RECONNECT_DELAY)
    connect_websocket()

def on_open(ws):
    """Handle WebSocket open."""
    global ws_instance
    ws_instance = ws
    print("WebSocket connected!")
    send_ws_message(ws, {
        "handler": "login",
        "username": BOT_USERNAME,
        "password": BOT_PASSWORD
    }, allow_dm=False)
    join_room(ws, DEFAULT_ROOM)
    send_ws_message(ws, {
        "handler": "message",
        "type": "text",
        "to": MASTER_USER,
        "text": "Bot connected, attempting to join room..."
    })

def connect_websocket(attempt=1):
    """Connect to Howdies WebSocket with controlled retry."""
    global token, captcha_state, ws_instance, last_dm_time
    if attempt > MAX_RECONNECT_ATTEMPTS:
        print("Max reconnect attempts reached. Stopping.")
        if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
            send_ws_message(ws_instance, {
                "handler": "message",
                "type": "text",
                "to": MASTER_USER,
                "text": "Max reconnect attempts reached. Please check bot."
            })
        return
    if captcha_state["pending"]:
        if time.time() - captcha_state["last_attempt"] < CAPTCHA_TIMEOUT:
            remaining = CAPTCHA_TIMEOUT - (time.time() - captcha_state["last_attempt"])
            print(f"Waiting for captcha response. Retrying in {remaining:.1f}s...")
            time.sleep(remaining)
            return connect_websocket(attempt)
        else:
            captcha_state["pending"] = False
            captcha_state["captcha_url"] = None
            print("Captcha timeout. Resetting captcha state.")
    new_token, captcha_url = get_token()
    if new_token:
        token = new_token
        ws_url = f"{WS_URL}?token={token}"
        print(f"Connecting to WebSocket: {ws_url} (Attempt {attempt}/{MAX_RECONNECT_ATTEMPTS})")
        ws = websocket.WebSocketApp(
            ws_url,
            on_open=on_open,
            on_message=on_message,
            on_error=on_error,
            on_close=on_close
        )
        ws_instance = ws
        ws_thread = threading.Thread(target=ws.run_forever)
        ws_thread.daemon = True
        ws_thread.start()
    elif captcha_url == "rate_limit":
        delay = 60
        print(f"Rate limit hit. Retrying in {delay}s...")
        if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
            send_ws_message(ws_instance, {
                "handler": "message",
                "type": "text",
                "to": MASTER_USER,
                "text": f"Rate limit hit. Retrying in {delay}s..."
            })
        time.sleep(delay)
        connect_websocket(attempt + 1)
    elif captcha_url:
        captcha_state["pending"] = True
        captcha_state["captcha_url"] = captcha_url
        captcha_state["target_user"] = MASTER_USER
        captcha_state["target_room"] = DEFAULT_ROOM
        captcha_state["last_attempt"] = time.time()
        print(f"Captcha required: {captcha_url}")
        if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
            send_ws_message(ws_instance, {
                "handler": "message",
                "type": "text",
                "to": MASTER_USER,
                "text": f"Captcha required: {captcha_url}. Please solve and send answer in DM."
            })
        time.sleep(CAPTCHA_TIMEOUT)
        connect_websocket(attempt + 1)
    else:
        delay = min(RECONNECT_DELAY * (2 ** attempt), 60)
        print(f"Cannot connect without token. Retrying in {delay}s...")
        if ws_instance and time.time() - last_dm_time > DM_COOLDOWN:
            send_ws_message(ws_instance, {
                "handler": "message",
                "type": "text",
                "to": MASTER_USER,
                "text": f"Failed to get token. Retrying in {delay}s..."
            })
        time.sleep(delay)
        connect_websocket(attempt + 1)

if __name__ == "__main__":
    try:
        os.chmod(".env", 0o600)
        os.chmod(__file__, 0o600)
    except Exception as e:
        print(f"Error setting file permissions: {e}")
    connect_websocket()
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        print("Shutting down bot...")
