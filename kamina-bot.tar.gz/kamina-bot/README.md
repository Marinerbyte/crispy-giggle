# Kamina Bot

A Node.js bot application that connects to Howdies chat platform with Gemini API integration for AI responses, translation, and image generation.

## Features

- **WebSocket Connection**: Connects to Howdies messaging platform using WebSockets
- **AI Response**: Uses Google's Gemini API for intelligent responses
- **Translation**: Translates messages to Hinglish on demand
- **Image Generation**: Generates images using Hugging Face's Stable Diffusion models
- **Database Storage**: Uses PostgreSQL for persistent storage of logs and user preferences

## Prerequisites

- Node.js (v18+ recommended)
- PostgreSQL database
- API keys for:
  - Google Gemini API
  - Hugging Face (for image generation)

## Installation

1. Extract the archive to your preferred location
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up environment variables by creating a `.env` file with:
   ```
   DATABASE_URL=your_postgresql_database_url
   GEMINI_API_KEY=your_gemini_api_key
   HUGGINGFACE_API_KEY=your_huggingface_api_key
   ```
4. Push the database schema:
   ```bash
   npm run db:push
   ```

## Running the App

### Development Mode

```bash
npm run dev
```

### Production Mode

```bash
npm run build
npm start
```

## Bot Commands

- `join <chatroom_name>` - Join a specific chatroom
- `/translate <username>` - Enable translation for a specific user
- `/offtranslate <username>` - Disable translation for a specific user
- Bot also responds to the keyword "kamina" with humorous replies

## Project Structure

- `client/`: Frontend React application
- `server/`: Express.js backend
- `server/bot/`: Bot implementation code
- `shared/`: Shared types and database schema

## Notes for Termux Deployment

To run the bot on Android using Termux:

1. Install Termux from F-Droid
2. Set up Node.js in Termux:
   ```bash
   pkg install nodejs-lts
   ```
3. Install PostgreSQL:
   ```bash
   pkg install postgresql
   ```
4. Initialize the database:
   ```bash
   initdb $PREFIX/var/lib/postgresql
   pg_ctl -D $PREFIX/var/lib/postgresql start
   ```
5. Follow the standard installation steps above